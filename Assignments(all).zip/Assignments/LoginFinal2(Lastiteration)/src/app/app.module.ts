﻿import { NgModule }      from '@angular/core'
import { BrowserModule } from '@angular/platform-browser'
import { AppComponent }  from './app.component'
import { HttpClientModule } from '@angular/common/http'
import { LoginComponent } from './login/login.component'
import { CustomerComponent} from './customer/customer.component'
import { AdminComponent } from './admin/admin.component'
import { FormsModule } from '@angular/forms'
import {Routes,RouterModule} from '@angular/router'
import { MerchComponent } from './merch/merch.component'
import { CouponComponent } from './coupon/coupon.component';

const routes:Routes=[
    {path:'',component:LoginComponent},
    {path:'login',component:LoginComponent},
    {path:'cust',component:CustomerComponent},
    {path:'admin',component:AdminComponent},
    {path:'merch',component:MerchComponent},
    {path:'coupon',component:CouponComponent}
]

@NgModule({
    imports: [
        BrowserModule,HttpClientModule,FormsModule,RouterModule.forRoot(routes)
    ],
    declarations: [
        AppComponent,
        LoginComponent,
        CustomerComponent,
    
        AdminComponent,
        MerchComponent,
        CouponComponent
    	],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }