package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentDetailsPage {
	WebDriver driver;
	
	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement cardholderName;
	
	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement debit;
	
	@FindBy(id="txtCvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement month;
	
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement year;
	
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement btnSubmit;

	public PaymentDetailsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getCardholderName() {
		return cardholderName;
	}

	public void setCardholderName(String cardholderName) {
		this.cardholderName.sendKeys(cardholderName);
	}

	public WebElement getDebit() {
		return debit;
	}

	public void setDebit(String debit) {
		this.debit.sendKeys(debit);
	}

	public WebElement getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public WebElement getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month.sendKeys(month);
	}

	public WebElement getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year.sendKeys(year);
	}

	public WebElement getBtnSubmit() {
		return btnSubmit;
	}

	public void setBtnSubmit() {
		this.btnSubmit.click();
	}
	

}
