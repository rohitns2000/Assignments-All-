package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UserInformationPage {
	WebDriver driver;
	//using xpath to locate
	@FindBy(xpath="\\*[@colspan=\"2\"]")
	@CacheLookup
	WebElement title;
	
	//using name to locate
	@FindBy(name="txtNM")
	@CacheLookup
	WebElement name;
	
	@FindBy(id="txtFirstName")
	@CacheLookup
	WebElement firstName;
	
	//using id to locate
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(id="txtFatherName")
	@CacheLookup
	WebElement fatherName;
	
	@FindBy(id="txtDOB")
	@CacheLookup
	WebElement dob;
	
	@FindBy(id="rdbMale")
	@CacheLookup
	WebElement rbMale;
	
	@FindBy(id="rdbFemale")
	@CacheLookup
	WebElement rbFemale;
	
	@FindBy(id="txtMobileNo")
	@CacheLookup
	WebElement mobileNo;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="txtLndLine")
	@CacheLookup
	WebElement landLine;

	@FindBy(id="rdbResAddress")
	@CacheLookup
	WebElement rbResidence;
	
	@FindBy(id="rdbOfficeAdd")
	@CacheLookup
	WebElement rboffice;
	
	@FindBy(id="txtAResidenceAdd")
	@CacheLookup
	WebElement address;
	
	@FindBy(id="btnSubmit")
	@CacheLookup
	WebElement btnSubmit;
	
	//initializing elements
	public UserInformationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title.sendKeys(title);
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName.sendKeys(fatherName);
	}

	public WebElement getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob.sendKeys(dob);
	}

	public WebElement getRbMale() {
		return rbMale;
	}

	public void setRbMale() {
		this.rbMale.click();
	}

	public WebElement getRbFemale() {
		return rbFemale;
	}

	public void setRbFemale() {
		this.rbFemale.click();
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getLandLine() {
		return landLine;
	}

	public void setLandLine(String landLine) {
		this.landLine.sendKeys(landLine);
	}

	public WebElement getRbResidence() {
		return rbResidence;
	}

	public void setRbResidence() {
		this.rbResidence.click();
	}

	public WebElement getRboffice() {
		return rboffice;
	}

	public void setRboffice() {
		this.rboffice.click();
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getBtnSubmit() {
		return btnSubmit;
	}

	public void setBtnSubmit() {
		this.btnSubmit.click();
	}
		

	
}
