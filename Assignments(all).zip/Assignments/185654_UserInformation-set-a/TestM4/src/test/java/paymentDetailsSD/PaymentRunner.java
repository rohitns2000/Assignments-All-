package paymentDetailsSD;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

//runner class for the specified payment test
@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/test/resources/paymentFeature"},glue= {"paymentDetailsSD"})
public class PaymentRunner {

}
