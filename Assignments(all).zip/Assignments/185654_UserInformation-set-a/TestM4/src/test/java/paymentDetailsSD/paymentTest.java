package paymentDetailsSD;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import page.PaymentDetailsPage;

public class paymentTest {
	private WebDriver driver;
	private PaymentDetailsPage pdp;
	
	//this is done before running any scenario... (Hook)
	//this class/java file specifies all the the respective feature file element
	@Before
	public void setUp() {
		String path = "D:\\Users\\rsammanw\\Desktop\\Selenium ChromeDriver and tutscloud\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver",path);
		driver = new ChromeDriver();
		//using implicit wait just after the driver is declared before throwing exception(eg-nosuchelement)
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
	
	@Given("^the user has the url$")
	public void the_user_has_the_url() throws Throwable {
		System.out.println("User is with the required url");
	}
	
	@When("^the user enters the url$")
	public void the_user_enters_the_url() throws Throwable {
		System.out.println("user enters url and is on PaymentDetails page");
	}

	@Then("^the user redirects to required page and title$")
	public void the_user_redirects_to_required_page_and_title() throws Throwable {
		System.out.println("User is on PaymentDetails page");
		System.out.println("validating title");
		driver.get("D:\\BDD WORKSPACE\\TestM4\\PaymentDetails.html");
		pdp= new PaymentDetailsPage(driver);
		String expected="Payment Details";
		String actual= driver.getTitle();
		//explicit wait giving driver to load and take the property getTitle()
		Thread.sleep(2000);
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.close();
	}

	@Given("^the user is on 'PaymentDetails' page$")
	public void the_user_is_on_PaymentDetails_page() throws Throwable {
		driver.get("D:\\BDD WORKSPACE\\TestM4\\PaymentDetails.html");
		pdp= new PaymentDetailsPage(driver);
	}

	@When("^the user clicks on make payment keeping Card Holder Name empty$")
	public void the_user_clicks_on_make_payment_keeping_Card_Holder_Name_empty() throws Throwable {
		pdp.setCardholderName("");
		pdp.setBtnSubmit();
	}

	@Then("^displays 'Please fill the Card holder name'$")
	public void displays_Please_fill_the_Card_holder_name() throws Throwable {
		String expected="Please fill the Card holder name";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user clicks on make payment keeping Debit Card Number empty$")
	public void the_user_clicks_on_make_payment_keeping_Debit_Card_Number_empty() throws Throwable {
		pdp.setCardholderName("Rohit");
		pdp.setDebit("");
		pdp.setBtnSubmit();
	}

	@Then("^displays 'Please fill the Debit card Number'$")
	public void displays_Please_fill_the_Debit_card_Number() throws Throwable {
		String expected="Please fill the Debit card Number";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user clicks on make payment keeping CVV empty$")
	public void the_user_clicks_on_make_payment_keeping_CVV_empty() throws Throwable {
		pdp.setCardholderName("Rohit");
		pdp.setDebit("98765");
		pdp.setCvv("");
		pdp.setBtnSubmit();
	}

	@Then("^displays 'Please fill the CVV'$")
	public void displays_Please_fill_the_CVV() throws Throwable {
		String expected="Please fill the CVV";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user clicks on make payment keeping Card Expiration Month empty$")
	public void the_user_clicks_on_make_payment_keeping_Card_Expiration_Month_empty() throws Throwable {
		pdp.setCardholderName("Rohit");
		pdp.setDebit("98765");
		pdp.setCvv("987");
		pdp.setMonth("");
		pdp.setBtnSubmit();
	}

	@Then("^displays 'Please fill expiration month'$")
	public void displays_Please_fill_expiration_month() throws Throwable {
		String expected="Please fill expiration month";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user clicks on make payment keeping Card Expiration Year empty$")
	public void the_user_clicks_on_make_payment_keeping_Card_Expiration_Year_empty() throws Throwable {
		pdp.setCardholderName("Rohit");
		pdp.setDebit("98765");
		pdp.setCvv("987");
		pdp.setMonth("12");
		pdp.setYear("");
		pdp.setBtnSubmit();
	}

	@Then("^displays 'Please fill the expiration year'$")
	public void displays_Please_fill_the_expiration_year() throws Throwable {
		String expected="Please fill the expiration year";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user details are validated$")
	public void the_user_details_are_validated() throws Throwable {
		pdp.setCardholderName("Rohit");
		pdp.setDebit("98765");
		pdp.setCvv("987");
		pdp.setMonth("12");
		pdp.setYear("2022");
		pdp.setBtnSubmit();
	}

	@Then("^displays 'Pan Card Registration Done successfully !!!'$")
	public void displays_Pan_Card_Registration_Done_successfully() throws Throwable {
		String expected="Pan Card Registration Done successfully !!!";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

}
