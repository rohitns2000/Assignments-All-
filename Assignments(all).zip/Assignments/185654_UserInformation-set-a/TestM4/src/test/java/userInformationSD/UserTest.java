package userInformationSD;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import page.UserInformationPage;

public class UserTest {
	
	private WebDriver driver;
	private UserInformationPage uip;
	
	//Hook is used to initialize the driver before every scenario
	@Before
	public void setUp() {
		String path = "D:\\Users\\rsammanw\\Desktop\\Selenium ChromeDriver and tutscloud\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver",path);
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
	//checking the title of the page...
	@Given("^the path of the url$")
	public void the_path_of_the_url() throws Throwable {
	    System.out.println("User is having path...");
	}

	@When("^the user enters the path$")
	public void the_user_enters_the_path() throws Throwable {
		System.out.println("User enters path...");
	}

	@Then("^the respective page opens$")
	public void the_respective_page_opens() throws Throwable {
		
		System.out.println("User is on UserInformation page");
		System.out.println("validating title");
		driver.get("D:\\BDD WORKSPACE\\TestM4\\UserInformation.html");
		uip= new UserInformationPage(driver);
		String expected="PAN CARD: User Information";
		String actual= driver.getTitle();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.close();
		
	}

	@Given("^the user is on 'UserInformation' page$")
	public void the_user_is_on_UserInformation_page() throws Throwable {
		driver.get("D:\\BDD WORKSPACE\\TestM4\\UserInformation.html");
		uip= new UserInformationPage(driver);
	}

	@When("^the user leaves Applicant Name empty$")
	public void the_user_leaves_Applicant_Name_empty() throws Throwable {
		uip.setName("");
		uip.setBtnSubmit();
	}

	@Then("^display 'Please fill the Applicant Name '$")
	public void display_Please_fill_the_Applicant_Name() throws Throwable {
		String expected="Please fill the Applicant Name ";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user leaves First Name empty$")
	public void the_user_leaves_First_Name_empty() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("");
		uip.setBtnSubmit();
	}

	@Then("^display 'Please fill the First Name '$")
	public void display_Please_fill_the_First_Name() throws Throwable {
		String expected="Please fill the First Name ";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user leaves Last Name empty$")
	public void the_user_leaves_Last_Name_empty() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("");
		uip.setBtnSubmit();
	}

	@Then("^display 'Please fill the Last Name '$")
	public void display_Please_fill_the_Last_Name() throws Throwable {
		String expected="Please fill the Last Name ";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user leaves Father Name empty$")
	public void the_user_leaves_Father_Name_empty() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("Sammanwar");
		uip.setFatherName("");
		uip.setBtnSubmit();
	}

	@Then("^display 'Please fill the Father Name '$")
	public void display_Please_fill_the_Father_Name() throws Throwable {
		String expected="Please fill the Father Name ";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user leaved Date of Birth empty$")
	public void the_user_leaved_Date_of_Birth_empty() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("Sammanwar");
		uip.setFatherName("Nitin");
		uip.setDob("");
		uip.setBtnSubmit();
	}

	@Then("^display 'Please fill the DOB'$")
	public void display_Please_fill_the_DOB() throws Throwable {
		String expected="Please fill the DOB";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user enters invalid Date of Birth$")
	public void the_user_enters_invalid_Date_of_Birth() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("Sammanwar");
		uip.setFatherName("Nitin");
		uip.setDob("01021976");
		uip.setBtnSubmit();
	}

	@Then("^display 'Please Enter valid date\\(dd-MM-yyyy\\)'$")
	public void display_Please_Enter_valid_date_dd_MM_yyyy() throws Throwable {
		String expected="Please Enter valid date(dd-MM-yyyy)";
		String actual= driver.switchTo().alert().getText();
		Thread.sleep(2000);
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user selects no gender$")
	public void the_user_selects_no_gender() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("Sammanwar");
		uip.setFatherName("Nitin");
		uip.setDob("01-02-1976");
		uip.setBtnSubmit();
	}

	@Then("^display 'Please select the Gender'$")
	public void display_Please_select_the_Gender() throws Throwable {
		String expected="Please select the Gender";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user leaves Mobile number empty$")
	public void the_user_leaves_Mobile_number_empty() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("Sammanwar");
		uip.setFatherName("Nitin");
		uip.setDob("01-02-1976");
		uip.setRbMale();
		uip.setMobileNo("");
		uip.setBtnSubmit();
	}

	@Then("^display 'Please fill Mobile no'$")
	public void display_Please_fill_Mobile_no() throws Throwable {
		String expected="Please fill Mobile no";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user enters invalid Mobile Number$")
	public void the_user_enters_invalid_Mobile_Number() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("Sammanwar");
		uip.setFatherName("Nitin");
		uip.setDob("01-02-1976");
		uip.setRbMale();
		uip.setMobileNo("99999999999");
		uip.setBtnSubmit();
	}

	@Then("^display 'Please enter valid mobile no'$")
	public void display_Please_enter_valid_mobile_no() throws Throwable {
		String expected="Please enter valid mobile no";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user leaves email empty$")
	public void the_user_leaves_email_empty() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("Sammanwar");
		uip.setFatherName("Nitin");
		uip.setDob("01-02-1976");
		uip.setRbMale();
		uip.setMobileNo("9999999999");
		uip.setEmail("");
		uip.setBtnSubmit();
	}

	@Then("^display 'Please fill the Email id '$")
	public void display_Please_fill_the_Email_id() throws Throwable {
		String expected="Please fill the Email id ";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user enters invalid email$")
	public void the_user_enters_invalid_email() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("Sammanwar");
		uip.setFatherName("Nitin");
		uip.setDob("01-02-1976");
		uip.setRbMale();
		uip.setMobileNo("9999999999");
		uip.setEmail("rohegooiuhr");
		uip.setBtnSubmit();
	}

	@Then("^display 'Please enter valid Email id'$")
	public void display_Please_enter_valid_Email_id() throws Throwable {
		String expected="Please enter valid Email id";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user leaves Landline empty$")
	public void the_user_leaves_Landline_empty() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("Sammanwar");
		uip.setFatherName("Nitin");
		uip.setDob("01-02-1976");
		uip.setRbMale();
		uip.setMobileNo("9999999999");
		uip.setEmail("rohit@gmail.com");
		uip.setLandLine("");
		uip.setBtnSubmit();
	}

	@Then("^display 'please fill the landline no'$")
	public void display_please_fill_the_landline_no() throws Throwable {
		String expected="please fill the landline no";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user does not select any communication$")
	public void the_user_does_not_select_any_communication() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("Sammanwar");
		uip.setFatherName("Nitin");
		uip.setDob("01-02-1976");
		uip.setRbMale();
		uip.setMobileNo("9999999999");
		uip.setEmail("rohit@gmail.com");
		uip.setLandLine("98765432");
		uip.setBtnSubmit();
	}

	@Then("^display 'Please select the Type of Communication '$")
	public void display_Please_select_the_Type_of_Communication() throws Throwable {
		String expected="Please select the Type of Communication ";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user leaves Address empty$")
	public void the_user_leaves_Address_empty() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("Sammanwar");
		uip.setFatherName("Nitin");
		uip.setDob("01-02-1976");
		uip.setRbMale();
		uip.setMobileNo("9999999999");
		uip.setEmail("rohit@gmail.com");
		uip.setLandLine("98765432");
		uip.setRboffice();
		uip.setAddress("");
		uip.setBtnSubmit();
	}

	@Then("^display 'please enter the Addresss'$")
	public void display_please_enter_the_Addresss() throws Throwable {
		String expected="please enter the Addresss";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user enters all the valid details$")
	public void the_user_enters_all_the_valid_details() throws Throwable {
		uip.setName("Rohit");
		uip.setFirstName("Rohit");
		uip.setLastName("Sammanwar");
		uip.setFatherName("Nitin");
		uip.setDob("01-02-1976");
		uip.setRbMale();
		uip.setMobileNo("9999999999");
		uip.setEmail("rohit@gmail.com");
		uip.setLandLine("98765432");
		uip.setRboffice();
		uip.setAddress("India");
		uip.setBtnSubmit();
	}

	@Then("^display 'Personal Details are Validated'$")
	public void display_Personal_Details_are_Validated() throws Throwable {
		String expected="Personal details are validated.";
		String actual= driver.switchTo().alert().getText();
		System.out.println(actual);
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.get("D:\\BDD WORKSPACE\\TestM4\\PaymentDetails.html");
		driver.close();
	}

//	@Then("^navigates to 'PaymentDetails'$")
//	public void navigates_to_PaymentDetails() throws Throwable {
//		
//		driver.close();
//	}
}
