package userInformationSD;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

//runner class for user information page
@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/test/resources/userFeature"},glue= {"userInformationSD"})
public class UserRunner {

}
